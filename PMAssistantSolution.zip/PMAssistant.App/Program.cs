﻿using System;
using System.IO;
using System.Collections.Generic;
using System.DirectoryServices.AccountManagement;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;
using System.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.Json;
using System.Linq;
using Microsoft.Office.Interop.Word;
using Microsoft.Office.Interop.Excel;

namespace PMAssistant.App
{
    class Program
    {
        public static IConfigurationRoot configuration;
        static string ProjectDirectory;
        static Product Product;
        static List<Product> Products;
        static Dictionary<string,string> Variables;
        static void Main(string[] args)
        {
            Initialize();

            var PMName = LoadPMDetails();
            Console.WriteLine($"Hi {PMName}! May the client be cooperative and your forcasts be accurate!");
            Console.WriteLine("Let's get started, This gonna be quick!");

            Console.WriteLine("What is the Product?");
            Console.WriteLine(string.Join(Environment.NewLine, (from x in Products select x.Name).ToList()));
            while (true) {
                var input = Console.ReadLine();
                Product = Products.Where(x => x.Name.ToLower() == input.ToLower()).SingleOrDefault();
                if (Product == null)
                {
                    Console.WriteLine("Pleaase provide a product from the list above..");
                }
                else
                {
                    Variables.Add("#Product#", Product.Name);
                    break;
                }
            }

            Console.WriteLine("Please specify the Project directory path:");
            ProjectDirectory = Console.ReadLine();
            var variablesFilePath = LoadVariablesFile(true);
            Console.WriteLine("Please fill the variables in the Excel workbook we've just opened for you");
            Console.WriteLine($"File didnt open? please open it manuall at this path: {variablesFilePath}");
            Console.WriteLine($"Please save your changes, close the file and hit enter...");
            Console.ReadLine();
            LoadVariablesFile();
            //Console.WriteLine("What is the client name?");
            //ClientName = Console.ReadLine();
            //Console.WriteLine("What is the quote number?");
            //QuoteNumber = Console.ReadLine();
            //Console.WriteLine("How many milestones?");
            //MilestonesCount= int.Parse(Console.ReadLine());
            //Console.WriteLine("When is the next Weekly Call (mm-dd-yy)?");
            //NextWeeklyCall = DateTime.Parse(Console.ReadLine());
            //Console.WriteLine($"Product:{Project.Product.Name}");
            //Console.WriteLine($"Client Name:{ClientName}");
            //Console.WriteLine($"Quote Number:{QuoteNumber}");
            //Console.WriteLine($"Milestones Count:{MilestonesCount}");
            //Console.WriteLine($"Next Weekly Call:{NextWeeklyCall}");
            //Console.WriteLine($"Project Directory path:{ProjectDirectory}");
            Console.WriteLine("Press enter to confirm and proceed..");
            Console.ReadLine();
            CreateKickoffDirectory();
            Console.WriteLine("Kickoff Directory created..");
            CreateMappingDirectory();
            Console.WriteLine("Mapping Doc Directory created..");
            CreateMinutesDirectory();
            Console.WriteLine("Minutes Directory created..");
            CreatePPDirectory();
            Console.WriteLine("Project Plan Directory created..");
            CreateSpecDocDirectory();
            Console.WriteLine("Spec Doc Directory created..");
            CreateWCFDirectory();
            Console.WriteLine("WCF Directory created..");
            Console.WriteLine("------------------------");
            Console.WriteLine("Press any key to exit..");
            Console.ReadLine();
        }

        private static void Initialize()
        {
            Variables = new Dictionary<string, string> { };
            configuration = new ConfigurationBuilder().SetBasePath(Directory.GetParent(AppContext.BaseDirectory).FullName).AddJsonFile("appsettings.json", false).Build();
            LoadProducts();
        }
        private static void LoadProducts()
        {
            Products = new List<Product> { };
            var lines = File.ReadAllLines(configuration.GetSection("PRODUCTS").Value);
            foreach(var line in lines)
            {
                var values = line.Split(',');
                Products.Add(new Product { Name = values[0], TemplatesDirectory = values[1] });
            }
        }
        static string CreateDirectory(string category)
        {
            var path = Path.Combine(ProjectDirectory, category);
            if(!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            return path;
        }
        static string LoadVariablesFile(bool createMode=false)
        {
            var sourceFilePath = configuration.GetSection("VARIABLES").Value;
            var destinationFilePath = Path.Combine(ProjectDirectory, $"Variables.csv");
            if (createMode)
            {
                File.Copy(sourceFilePath, destinationFilePath);

                var excelApp = new Excel.Application();
                excelApp.Visible = true;
                excelApp.Workbooks.OpenText(destinationFilePath, Comma: true);
            }
            else
            {
                var lines = File.ReadAllLines(destinationFilePath);
                foreach (var line in lines)
                {
                    var values = line.Split(',');
                    Variables.Add(values[0], values[1]);
                }
                var fullName = GetVariableValue("#Client PM Name#");
                Variables.Add("#Client PM First Name#", fullName.Split(' ')[0]);
            }
            return destinationFilePath;
        }
        static void CreateKickoffDirectory()
        {
            var path = CreateDirectory("Kickoff");
        }
        static void CreateMappingDirectory()
        {
            var path = CreateDirectory("Mapping Doc");
        }
        static void CreateMinutesDirectory()
        {
            var path = CreateDirectory("Minutes");
            var sourceFilePath =  configuration.GetSection("MINUTES_TEMPLATE").Value;
            var fileName = Path.GetFileName(sourceFilePath);
            DateTime nextWeeklyCall = GetNextWeeklyCall();
            int count;
            var desiredMoMFilesConfig = configuration.GetSection("DESIRED_MoM_FILES").Value;
            if (!int.TryParse(desiredMoMFilesConfig, out count))
            {
                count = 8;
            }
            for (int i = 1; i <= count; i++)
            {
                Word._Application Application = new Word.Application();
                //Application.Visible = false;
                //Application.ScreenUpdating = false;
                //Application.WindowState = WdWindowState.wdWindowStateMinimize;

                var date = nextWeeklyCall.AddDays(7 * i);
                Variables.Add("#DateTime#", date.ToShortDateString());
                var destinationFilePath = Path.Combine(path, GetVariablesValue(fileName).Replace("#yyyyMMdd#", date.ToString("yyyyMMdd")));
                File.Copy(sourceFilePath, destinationFilePath);
                Application.Documents.Open(destinationFilePath);
                SearchReplace(Application);
                Application.Documents.Close();
                Variables.Remove("#DateTime#");
            }
        }

        private static void SearchReplace(Word._Application Application)
        {
            object missing = System.Reflection.Missing.Value;

            Find findObject = Application.Selection.Find;
            foreach (var item in Variables)
            {
                findObject.ClearFormatting();
                findObject.Text = item.Key;
                findObject.Replacement.ClearFormatting();
                findObject.Replacement.Text = item.Value;

                object replaceAll = WdReplace.wdReplaceAll;
                findObject.Execute(ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing, ref missing, ref missing,
                    ref replaceAll, ref missing, ref missing, ref missing, ref missing);
            }
        }
        private static DateTime GetNextWeeklyCall()
        {
            var dateTime = DateTime.Now;
            if(!DateTime.TryParse(GetVariablesValue("#Next Weekly Call#"), out dateTime))
            {
                Console.WriteLine("WARNING, Next weekly call variable not provided, or has invalid value, setting the next weekly call in one week..");
                dateTime = DateTime.Now;
            }
            return dateTime;
        }

        static void CreatePPDirectory()
        {
            var path = CreateDirectory("PP");
            var fileName = configuration.GetSection("PROJECT_PLAN_TEMPLATE").Value;
            var sourceFilePath = Path.Combine(Product.TemplatesDirectory,fileName);
            var destinationFilePath = Path.Combine(path, fileName);
            if(!File.Exists(destinationFilePath))
                File.Copy(sourceFilePath, destinationFilePath);
        }
        static void CreateSpecDocDirectory()
        {
            var path = CreateDirectory( "Spec Doc");

        }
        static void CreateWCFDirectory()
        {
            var path = CreateDirectory("WCF");
            var sourceFilePath = configuration.GetSection("WCF_TEMPLATE").Value;
            var sourceEmailPath = configuration.GetSection("WCF_EMAIL").Value;
            var fileName = Path.GetFileName(sourceFilePath);
            var EmailName = Path.GetFileName(sourceEmailPath);

            var milestones = LoadMilestones();
            foreach(var milestone in milestones)
            {
                Variables.Add("#NO#", milestone.Id.ToString());
                Variables.Add("#Milestone Description#", milestone.Description.Contains("Milestone") ? "" : $"Milestone {milestone.Id}: " + milestone.Description);

                var destinationFilePath = Path.Combine(path, GetVariablesValue(fileName));
                File.Copy(sourceFilePath, destinationFilePath);

                Excel.Application excelApp = new Excel.Application();
                excelApp.Visible = false;
                Excel.Workbook excelWorkbook = excelApp.Workbooks.Open(destinationFilePath,
                    0, false, 5, "", "", false, Excel.XlPlatform.xlWindows, "",
                    true, false, 0, true, false, false);
                try
                {
                    Excel.Sheets excelSheets = excelWorkbook.Worksheets;
                    Excel.Worksheet excelWorksheet = (Excel.Worksheet)excelSheets.get_Item(configuration.GetSection("WCF_SHEET_NAME").Value);
                    Excel.Range excelCell = excelWorksheet.get_Range("A1", "Z100");
                    foreach (Excel.Range cell in excelCell.Cells)
                    {
                        if (CellContainsVariable(cell.Value2))
                        {
                            cell.Value2 = GetVariablesValue(cell.Value2);
                        }
                    }
                    excelWorkbook.Save();

                    //Generate a PDF Version
                    object outputFileName = excelWorkbook.FullName.Replace(".xlsx", ".pdf");
                    excelWorkbook.ExportAsFixedFormat(XlFixedFormatType.xlTypePDF, outputFileName);

                    //Generate the email body
                    var destinationEmailPath = Path.Combine(path, GetVariablesValue(EmailName));
                    var emailBody = File.ReadAllText(sourceEmailPath);
                    var milestoneBody = GetVariablesValue(emailBody);
                    File.WriteAllText(destinationEmailPath, milestoneBody);

                    Variables.Remove("#NO#");
                    Variables.Remove("#Milestone Description#");
                }
                catch
                (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                excelWorkbook.Close();
            }
        }

        private static List<Milestone> LoadMilestones()
        {
            var milestones = new List<Milestone> { };
            int count;
            var maxMilestonesCountConfig = configuration.GetSection("MAX_MILESTONES_COUNT").Value;
            if(!int.TryParse(maxMilestonesCountConfig, out count))
            {
                count = 4;
            }
            for (int i = 1; i <= count; i++)
            {
                var key = $"#M{i}#";
                var milesStone = GetVariableValue(key);
                if(!string.IsNullOrEmpty(milesStone) && !milesStone.Contains("Please"))
                   milestones.Add(new Milestone { Id = i, Description = milesStone });
            }
            return milestones;
        }

        private static bool CellContainsVariable(dynamic value)
        {
            return (value != null && value.GetType() == typeof(string) && ((string)value).Contains('#'));
        }
        private static string GetVariableValue(dynamic value)
        {
            if (Variables.ContainsKey((string)value))
            {
                var variable = Variables[(string)value];
                if (string.IsNullOrEmpty(variable))
                    return "<Not Available>";
                return variable;
            }
            return (string)value;
        }
        private static string GetVariablesValue(string value)
        {
            foreach(var item in Variables)
            {
                value=value.Replace(item.Key, item.Value);
            }
            return value;
        }
        private static string LoadPMDetails()
        {
            var name = string.Empty;
            var emailAddress = string.Empty;
            try
            {
                name = UserPrincipal.Current.DisplayName;
                emailAddress = UserPrincipal.Current.EmailAddress;
            }
            catch (Exception)
            {
                name = string.Empty;
                emailAddress = string.Empty;
            }
            if(string.IsNullOrEmpty(name) || string.IsNullOrEmpty(emailAddress))
            {
                Console.WriteLine("Unable to fech your account information..");
                Console.WriteLine("Please enter your name:");
                name = Console.ReadLine();
                Console.WriteLine("and your email address:");
                emailAddress = Console.ReadLine();
            }
            Variables.Add("#PM Name#", name);
            Variables.Add("#PM Email#", emailAddress);
            return name;
        }

    }

    class Milestone
    {
        public int Id { get; set; }
        public string Description { get; set; }
    }
    class Product
    {
        public string Name { get; set; }
        public string TemplatesDirectory { get; set; }
    }
}
